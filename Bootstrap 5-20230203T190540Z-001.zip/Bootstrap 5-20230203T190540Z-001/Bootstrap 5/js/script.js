console.log("Hello World");
var num1 = 10;
var num2 = 10;
var r=num1 +num2;
console.log("resultado :" + r);
var rm=num1*num2;
console.log("Resultado de multipliacion : " + rm);
var rz=Math.sqrt(1249) ;
var re=Math.trunc(rz);
console.log("la raiz de 1249 es "+ re+" En numero entero")

const puederSerPrimo = (numero = undefined) => {
    if (numero === undefined) return console.warn(`No se 
    puede dejar vacio`)
    if (numero === 0) return console.log(`El numero 
    ${numero} no es primo.`)
    if (numero === 1) return console.log(`El numero 
    ${numero} no es primo.`)
    if (!numero) return console.error(`No se puede
    colocar texto`)
  
    let basesDePrimos = [2, 3, 5, 7, 11, 13]
  
    for (let z = 0; z <= basesDePrimos.length; z++) {
      while (numero === basesDePrimos[z]) {
        return console.log(`El ${numero} si es primo.`)
      }
    }
  
    divisiones = 0
  
    while (divisiones < 6) {
  
      for (let n = 0; n <= basesDePrimos.length; n++) {
  
        let residuo = numero % basesDePrimos[n]
  
        while (residuo === 0) {
          return console.log(`El ${numero} no es primo.`)
        }
      }
      divisiones++
    }
  
    return console.log(`El ${numero} si es primo.`)
  
  }
  
  const numeroDePrimos = (inicio, final) => {
    for (let v = inicio; v <= final; v++) {
      let primos = []
      primos.push(puederSerPrimo(v))
  
    }
  }
  
  numeroDePrimos(0, 500000);