<?php
 if(isset($_POST['submit'])) {
    
    $user = $_POST['user'];
    $pass = $_POST['pass'];
    $userDB = "tca@gmail.com";
    $passDB = "123";

    if (isset($_POST['user'])) {
        if ($user === $userDB) {
            header("Location: ../home.html");
        } else {
            echo '<script language="javascript">alert("Error en datos");</script>';
        }
    }
 }